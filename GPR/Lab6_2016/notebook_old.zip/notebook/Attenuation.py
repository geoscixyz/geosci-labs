import numpy as np
import matplotlib.pyplot as plt
from scipy.constants import mu_0, epsilon_0

def WaveVelSkind(frequency, epsr, sigma):
    omega = np.pi*np.complex128(frequency)
    k = np.sqrt(omega**2*mu_0*epsilon_0*epsr-1j*omega*mu_0*sigma)
    alpha = k.real
    beta = -k.imag
    return omega.real/alpha, 1./beta

def WaveVelandSkindWidget(epsr, sigma):
    frequency = np.logspace(1, 9, 61)
    vel, skind = WaveVelSkind(frequency, epsr, 10**sigma)
    figure, ax = plt.subplots(1,2, figsize = (10, 4))
    ax[0].loglog(frequency, vel, 'b', lw=3)
    ax[1].loglog(frequency, skind, 'r', lw=3)
    ax[0].set_ylim(1e5, 1e9)
    ax[1].set_ylim(1e-1, 1e7)
    ax[0].set_xlabel('Frequency (Hz)')
    ax[0].set_ylabel('Velocity (m/s)')
    ax[1].set_xlabel('Frequency (Hz)')
    ax[1].set_ylabel('Skin Depth (m)')
    ax[0].grid(True)
    ax[1].grid(True)

    plt.show()
    return
